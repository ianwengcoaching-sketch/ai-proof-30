# CloudDesk 上班資料夾

> AI Proof 30 示範資料。Kelly Lin 是組合案例，不是真人；CloudDesk Software 與這個資料夾裡的人名、客戶、數字全部虛構。

## 這裡是誰的

Kelly Lin，CloudDesk Software 的 Digital Marketing Specialist，向行銷經理 Daniel 報告。CloudDesk 是台北的 B2B SaaS，60 人，做雲端客服工單系統。Kelly 管付費廣告、每月一場 webinar，還有公司的 LinkedIn 公司頁。

這個資料夾只放上班的東西。她的求職資料在另一個資料夾，這裡不碰。

## 資料夾

- `01-本週/`：本週待辦、週會紀錄。問「這週先做什麼」，先看這裡。
- `02-專案/`：進行中的專案。小專案一份檔，大專案一個資料夾（例如 `客戶聚會/`）。
- `03-報告/`：每月成效。

## 規則

- 回答時說清楚是從哪一份檔案看到的。
- 數字只用檔案裡有的，沒有就說沒有，不估。
- 中文標點全形。

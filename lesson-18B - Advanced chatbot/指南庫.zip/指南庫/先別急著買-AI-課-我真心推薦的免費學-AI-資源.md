# 先別急著買 AI 課：我真心推薦的免費學 AI 資源
網址：https://www.careergoglobal.com/guide/C2YXabi3nCGiX3fWD

先別急著買 AI 課：我真心推薦的免費學 AI 資源｜Career.goglobal

FREE GUIDE ・ AI

學 AI 不用花一毛錢，也不用先修完什麼課。這份清單給你我真心推薦的免費資源，和正確的使用順序。

我帳號有史以來最多人看的一支影片，是教大家讓 Claude 直接去 Indeed 撈職缺：15 萬次播放，4,900 則留言。

但說個實話：那支影片裡的每一步，都不需要你先「學會 AI」。

我的正職是在都柏林帶歐美 PM 團隊，做 AI strategy governance。這幾年我在大公司裡看得很清楚：真正把 AI 用起來的，從來不是上最多課的人，是最快把 AI 塞進一個真實任務的人。

你缺的不是另一門課，是今天就把 AI 用在你正卡住的那件事上。下面這些資源，全部免費，我按照「求職的人該用的順序」排好了。

## 01我的免費指南庫

適合：想直接用 AI 解決求職問題的人

不是因為是我寫的才排第一。是因為最快學會 AI 的方式，就是拿它解決你現在最痛的事：履歷、職缺、面試。每一篇都是完整方法，prompt 全文直接給你，不鎖 email。

- 履歷讓 Claude 直接去 Indeed 撈為你開的職缺：海投變精準狙擊
- 領英 AI 幫你做領英健檢：把整份 LinkedIn 丟給 AI 逐項體檢
- Claude AI 自信滿滿地說謊，你怎麼知道？3 個防幻覺 prompt
- Claude 用 Claude 輕鬆建立品牌簡報 AI Skill

免費看所有指南 →

## 02 Anthropic Academy

適合：想把 Claude 用熟的人

Claude 官方的免費課程。我自己的求職系統全部建立在 Claude 上，如果你只想選一個 AI 工具用到精，選它。從 prompting 基礎到建 AI agent 都有，第一手、不過時。

anthropic.com/learn →

## 03 Elements of AI

適合：想搞懂「AI 到底是什麼」的人

赫爾辛基大學做的免費線上課，全球上百萬人上過。不用寫程式、不用數學底子，用大白話講清楚 AI 的能與不能。如果你常常覺得「大家都在講 AI，但我連它是什麼都說不清」，從這裡開始。

elementsofai.com →

## 04 Microsoft AI for Beginners

適合：喜歡按表操課、要有進度感的人

GitHub 上的 12 週免費課綱，一週一個主題，從 AI 的歷史一路講到神經網路。全部開源，自己排進度。適合那種「給我一張課表我就會走完」的人。

github.com/microsoft/AI-For-Beginners →

## 05 Google Machine Learning Crash Course

適合：想往 AI 相關職位轉的人

影片＋互動練習，比你想像的好消化。先說清楚：求職用 AI 完全不需要它。但如果你的目標是轉進 AI 相關職位，需要在面試裡講得出原理，這是免費的第一塊磚。

developers.google.com/machine-learning/crash-course →

> 順序建議：先從指南庫挑一篇動手做（今天），再上 Anthropic Academy 把 prompting 練熟（本週）。03 到 05 是理論底子，需要再回頭補，不需要就跳過。工具是配角，你的 offer 才是主角。

## 資源不是拿來收藏的

你的收藏夾裡，是不是已經躺著十篇「改天再看」的 AI 教學？

不是你懶，是順序錯了。先收藏再找時間學，永遠學不完；先有任務，再找工具，一個下午就上手。

所以這一頁的規則只有一條：

- ✅ 今天（30 分鐘）：從指南庫挑一篇，跟著做完。建議從「讓 Claude 去 Indeed 撈職缺」開始，做完你手上就有一份為你開的職缺清單。
- ✅ 本週（2 小時）：Anthropic Academy 上完 prompting 基礎，之後每個指南你都能自己改、自己延伸。
- ✅ 本月（看需要）：要理論底子再去 03 到 05 補課。不需要就別補，把時間拿去投遞。

挑一個，今天就開始。動手，永遠贏過收藏。加油！

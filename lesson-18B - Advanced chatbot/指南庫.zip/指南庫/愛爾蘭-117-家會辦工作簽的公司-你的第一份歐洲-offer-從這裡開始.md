# 愛爾蘭 117 家會辦工作簽的公司：你的第一份歐洲 offer 從這裡開始
網址：https://www.careergoglobal.com/guide/g4AY5HKfeTSEP4Bc3

歐元區唯一的英語系國家，2024 年核發超過 39,000 張工作許可。這份清單把每一家有實際辦簽紀錄的公司、地點、產業和職缺頁全部列給你，附上學生該用的投遞順序。

大家聊海外工作，講來講去都是美國、新加坡、日本，然後是荷蘭跟德國。愛爾蘭幾乎不在名單上。

但如果你是還在念書、英文是你最大武器、又不想再多學一種語言的學生，愛爾蘭其實是全歐洲最不該被跳過的地方。

理由很單純：它是歐元區唯一的英語系國家。你不用先花兩年考德文 B2、不用擔心荷蘭公司偷偷偏好會荷語的人。你的履歷從第一天就是「可讀的」。

而且這裡是 Google、Meta、Apple、Stripe、Pfizer 的歐洲總部所在地。這些公司在都柏林不是設個銷售辦公室，是設整個歐洲的工程和營運中樞。他們僱用外國人不是特例，是日常。

下面這份清單有 117 家公司，全部都有實際幫外國人辦工作許可的紀錄。我按產業分好、標好地點、附上官方職缺頁。但先讀完前面兩段，不然你會用錯方式投。

- 39,000+：2024 年核發的 工作許可數
- 相較前一年 成長幅度：+27%
- 都柏林以外的 職缺占比：56%

## 先搞懂：愛爾蘭的工簽怎麼運作

這是所有人第一個問的問題，也是最多人一開始就搞錯的地方。

愛爾蘭的許可制度是「公司主導」的。簽證是公司幫你申請，不是你自己申請。所以順序永遠是：先拿到簽好的 offer，才會有任何文件開始跑。

換句話說，你要做的事情從頭到尾只有一件：讓一家公司願意錄取你。剩下的行政流程是他們的事。

| 項目 | Critical Skills 許可（首選） | General 許可 |
|---|---|---|
| 薪資門檻 | €40,904／年（2026 年 3 月起，適用關鍵技能清單職位） | €36,605／年 |
| 勞動市場測試 | 不需要，公司給 offer 後可立刻申請 | 需要，公司必須證明找不到合適的歐盟人選 |
| 處理時間 | 4 到 8 週 | 4 到 8 週 |
| 之後呢 | 21 個月後拿 Stamp 4（不受限工作權），滿 5 年可申請入籍 | 依續簽狀況而定 |

> 一個大多數人不知道的規則改動：依 Employment Permits Act 2024（2024 年 9 月 2 日生效，線上換雇主申請自 2025 年 4 月 28 日起受理），持許可者在愛爾蘭工作滿 9 個月後可以換雇主，不需要重新申請一張新許可，改送一份 Change of Employer 申請即可，且免勞動市場測試。
> 但有一個關鍵限制，沒人跟你講：新工作必須留在同一個職業分類。Critical Skills 許可是同 3 位數 SOC 職業碼（例如各類工程職之間可以互跳），General 許可更嚴，限同 4 位數 SOC 碼。換句話說，你不能拿客服的許可跳去做軟體工程。此外，換雇主申請最多 3 次，原許可需至少還有 2 個月效期，且必須在新許可核發後 1 個月內到職。
> 這對學生的意義是：第一份工作不必是夢想公司，但必須是對的職業分類。與其為了拿簽證硬接一個分類錯的職位，不如在你本來的專業領域裡，先挑一家沒那麼有名、但確實在辦簽的公司進場。9 個月後你就是「已經在愛爾蘭有工作的候選人」，那時候投 Google 跟你現在從台灣投，是完全不同的難度。

上述規則依 DETE 官方 Changing Employer 頁面。SOC 職業碼的比對請在接受任何 offer 前確認，這一步做錯的代價是 9 個月。

## 都柏林是主場，但不是唯一解

都柏林拿走 44% 的許可，聽起來很多。但反過來看，56% 的職缺散在全國其他地方，而那些地方的競爭者少得多。

Cork 是製藥和醫療器材重鎮。Galway 有 Boston Scientific、Medtronic 和幾家大醫院。Limerick 有 Northern Trust、Analog Devices、Johnson & Johnson。Kildare 有 Intel 的晶圓廠。

而且房租差很多。在 Cork 年薪 €50,000 的生活品質，會贏過都柏林的 €65,000。學生剛畢業第一份工作，比起「地點好聽」，先拿到身分和存款更重要。

## Trusted Partner：學生最該優先投的那一類

愛爾蘭政府有一個 Trusted Partner 制度。已註冊的雇主，許可申請的處理時間從標準的 4 到 8 週縮短成 2 到 4 週。

為什麼這對學生特別關鍵？因為你多半有時間壓力：畢業日期、簽證到期日、家裡能撐多久。快 4 週，有時候就是能不能接得上的差別。

Google、Meta、Stripe、Microsoft、Apple、HubSpot、Snowflake、Datadog 都是 Trusted Partner。下面清單裡我用 TRUSTED PARTNER 標出來了。

## 01科技：Trusted Partner 與最高辦簽量

- 1 Google Ireland TRUSTED PARTNER 都柏林・搜尋 / 廣告 / 雲端 / AI 歐洲總部在都柏林 Docklands，數千名工程師分布在 backend、基礎架構、SRE、機器學習。全國辦簽量最高的科技公司之一。資深職位總報酬約 €130k 到 €190k。 careers.google.com →
- 2 Meta Platforms Ireland TRUSTED PARTNER 都柏林・社群 / 基礎架構 / AI 歐洲工程中樞。團隊涵蓋基礎架構、隱私、integrity 和產品工程。搬遷支援強，也是都柏林國際化程度最高的職場之一。資深總報酬約 €145k 到 €200k。 metacareers.com →
- 3 Microsoft Ireland Research TRUSTED PARTNER 都柏林・雲端 / 企業軟體 / AI 歐洲營運中心，工程團隊橫跨 Azure、Office 365 和 LinkedIn。全國最活躍的科技辦簽者之一。 careers.microsoft.com →
- 4 Apple Distribution International TRUSTED PARTNER Cork / 都柏林・消費性科技 / 服務 歐洲總部設在 Cork，國際招聘歷史最久的公司之一。工程團隊涵蓋 Maps、Siri 和服務基礎架構。 apple.com/careers →
- 5 Amazon Web Services EMEA 都柏林・雲端 / 基礎架構 Amazon 在愛爾蘭有多個法人實體，工程團隊橫跨 AWS 服務、零售技術與開發中心。搬遷和辦簽流程都非常成熟。 amazon.jobs →
- 6 Stripe Technology Company TRUSTED PARTNER 都柏林・金融科技 / 支付 由愛爾蘭兄弟創辦，都柏林是舊金山以外最大的工程中心。支付基礎架構、backend、資安、開發者平台。資深總報酬約 €130k 到 €175k。 stripe.com/jobs →
- 7 HubSpot Ireland TRUSTED PARTNER 都柏林・SaaS / 行銷科技 歐洲總部。除了大型工程團隊，還有商務和客戶成功職缺，非技術背景的學生最該優先看的一家。 hubspot.com/jobs →
- 9 Snowflake TRUSTED PARTNER 都柏林・雲端資料平台 資料庫核心、分散式系統、雲端資料工程。 careers.snowflake.com →
- 10 Datadog Ireland TRUSTED PARTNER 都柏林・可觀測性 / 監控 / 資安 都柏林是它全球最大的研發據點之一，不是業務辦公室。2026 年正在大量招 AI/ML 工程。 careers.datadoghq.com →

## 02科技：積極辦簽中

- 11 Salesforce (SFDC Ireland) 都柏林・SaaS / CRM 都柏林規模可觀，工程團隊涵蓋平台、backend 和雲端基礎架構。 salesforce.com/company/careers →
- 12 LinkedIn 都柏林・職業社群 / 科技 國際總部設在都柏林。工程、產品、業務、行銷、營運都有。 careers.linkedin.com →
- 13 TikTok Technology 都柏林・社群 / 科技 都柏林營運規模不小，內容、信任與安全、工程、營運都在積極招國際人才。 careers.tiktok.com →
- 14 Workday 都柏林・HR 科技 / SaaS 歐洲總部。工程、客戶成功、財務職缺。以「對搬遷來的新人有系統化 onboarding」著稱。 workday.com/careers →
- 15 Indeed 都柏林・求職平台 / 科技 國際總部在都柏林。搜尋、backend、資料與 ML 工程。 indeed.com/cmp/Indeed/jobs →
- 16 MongoDB 都柏林・資料庫 / 雲端 資料庫核心、雲端平台、分散式系統、開發者工具。 mongodb.com/careers →
- 17 Intercom 都柏林・客戶溝通 / SaaS 愛爾蘭本土創辦。Backend、full-stack、ML、平台工程。 intercom.com/careers →
- 18 Twilio 都柏林・通訊科技 / SaaS Backend、通訊基礎架構、API 開發。 twilio.com/company/jobs →
- 19 Zendesk International 都柏林・客服科技 / SaaS Backend、frontend、資料、平台工程。 zendesk.com/jobs →
- 20 Squarespace 都柏林・網站建置 / 科技 Backend、frontend、基礎架構工程。 squarespace.com/about/careers →
- 21 PayPal Europe Services 都柏林・金融科技 / 支付 工程、法遵、營運職缺。 paypal.com/jobs →
- 22 eBay Europe Services 都柏林・電商 / 科技 歐洲樞紐的技術、產品、營運職缺。 ebayinc.com/company/careers →
- 23 Bloomberg Data Management Services 都柏林・金融資料 / 科技 支援 Bloomberg 全球金融資料基礎架構的資料、分析與技術職缺。 bloomberg.com/careers →
- 24 SAP Ireland 都柏林・企業軟體 企業軟體工程、顧問與支援職缺。 sap.com/careers →
- 25 IBM Ireland 都柏林・企業科技 / 顧問 愛爾蘭有多個法人實體，涵蓋技術顧問、雲端與 AI。 ibm.com/employment →
- 26 Oracle Ireland 都柏林・企業軟體 / 雲端 雲端基礎架構、資料庫與企業軟體工程。 oracle.com/corporate/careers →
- 27 OpenAI Ireland 最新 都柏林・AI / 研究 愛爾蘭最新確認的辦簽公司。都柏林據點成長中，工程與營運職缺陸續開出。 openai.com/careers →
- 28 WhatsApp Ireland 都柏林・科技 / 通訊 屬於 Meta 集團。都柏林的工程與營運職缺。 metacareers.com →

## 03科技：沒人在講但一直在辦簽

這一段是整份清單最值得學生看的地方。競爭者少，錄取率高，而且一樣拿 Critical Skills 許可。

- 29 Poppulo 冷門推薦 Cork・企業溝通 / SaaS 愛爾蘭本土創辦、總部在 Cork 的企業溝通公司。Full-stack、backend、雲端工程。Cork 生活成本明顯低於都柏林。是那種沒什麼人知道、但辦簽紀錄非常穩定的公司。 poppulo.com/careers →
- 30 Experian 都柏林・資料分析 / 信用服務 總部設在都柏林（不是分公司，是全球總部）。資料、分析、工程與財務職缺。 experian.com/careers →
- 31 Fiserv Solutions Europe 都柏林・金融科技 技術、營運與財務職能。 careers.fiserv.com →
- 32 Seagate Technology Derry / 都柏林・資料儲存 工程、製造與技術職缺。持續穩定的辦簽者。 seagate.com/careers →
- 33 Qualcomm Cork・半導體 / 無線技術 Cork 的半導體、無線與嵌入式工程。 qualcomm.com/company/careers →
- 34 Analog Devices International Limerick / Cork・半導體 愛爾蘭營運規模大。Limerick 的競爭跟成本都低。 analog.com/careers →
- 35 Applied Materials Ireland 都柏林・半導體設備 愛爾蘭半導體設備領域最活躍的辦簽者之一。工程與技術職缺。 appliedmaterials.com/careers →
- 36 KLA-Tencor Ireland 都柏林・半導體設備 半導體設備工程職缺。 kla.com/company/careers →
- 37 Lam Research Ireland 都柏林・半導體設備 在愛爾蘭有實質據點，但幾乎沒人注意。工程與技術職缺。 lamresearch.com/careers →
- 38 Infineon Technologies Ireland 都柏林・半導體 半導體工程與技術職缺。 infineon.com/careers →
- 39 Ericsson 都柏林 / Athlone・電信 / 科技 軟體、網路工程與技術職缺。 ericsson.com/careers →
- 40 Huawei Technologies Ireland 都柏林・電信 / 科技 工程與技術職缺。都柏林市場上的活躍辦簽者。 huawei.com/careers →
- 41 Wayfair 都柏林・電商 / 科技 技術、資料、產品與營運職缺。 wayfair.com/careers →
- 42 Cloudflare 都柏林・資安 / 網路 網路安全、基礎架構與工程職缺。 cloudflare.com/careers →
- 43 Palantir 都柏林・資料分析 / AI Forward Deployed Engineering 與資料分析職缺。 palantir.com/careers →
- 44 Expedia Group 都柏林・旅遊科技 技術、產品、資料與商務職缺。 lifeatexpedia.com →
- 45 Gartner 都柏林・研究 / 技術顧問 研究、業務、顧問與技術職缺。商管背景學生的好切入點。 jobs.gartner.com →
- 46 Version 1 Software 都柏林・IT 服務 / 顧問 愛爾蘭本土創辦的 IT 服務與顧問公司。技術與顧問職缺的活躍辦簽者。 version1.com/careers →
- 47 Mastercard Ireland 都柏林・金融科技 / 支付 工程、資料、產品與營運。 mastercard.com/careers →

## 04顧問與專業服務

學生最容易低估的一塊。這些公司的辦簽量比多數科技產品公司大得多，移民流程超級成熟，而且會招應屆畢業生。

- 48 Accenture 學生友善 都柏林・顧問 / 技術服務 愛爾蘭最大的雇主之一，辦簽量全國前五。技術、顧問、營運與財務。 accenture.com/ie-en/careers →
- 49 Tata Consultancy Services 都柏林・IT 顧問 / 服務 跨多個法人實體，是愛爾蘭最活躍的辦簽者之一。 tcs.com/careers →
- 50 Ernst & Young 都柏林 / Cork / Galway / Limerick・專業服務 風險、法遵與技術轉型人才需求強。 ey.com/en_ie/careers →
- 51 Grant Thornton 都柏林・專業服務 / 顧問 審計、諮詢、稅務與顧問職缺。長期高量辦簽。 grantthornton.ie/careers →
- 52 Deloitte Ireland 都柏林 / Cork / Limerick・專業服務 技術轉型、審計、諮詢與顧問。 deloitte.com/ie/en/careers →
- 53 KPMG Ireland 都柏林 / Cork・專業服務 審計、諮詢、稅務科技與風險。 kpmg.com/ie/careers →
- 54 PwC Ireland 都柏林 / Cork / Galway・專業服務 財務、審計、稅務科技與諮詢。 pwc.ie/careers →
- 55 Cognizant Technology Solutions 都柏林・IT 顧問 / 服務 IT 顧問與服務職缺。活躍的高量辦簽者。 careers.cognizant.com →
- 56 Infosys 都柏林・IT 顧問 / 服務 跨多個愛爾蘭實體的技術與顧問職缺。 infosys.com/careers →
- 57 Wipro 都柏林・IT 顧問 / 服務 跨愛爾蘭實體的技術與顧問職缺。 wipro.com/careers →
- 58 HCL Technologies 都柏林・IT 服務 IT 服務與技術職缺。 hcltech.com/careers →
- 59 NTT DATA Services Ireland 都柏林・IT 顧問 / 服務 技術顧問與 IT 服務職缺。 nttdata.com/careers →
- 60 Tech Mahindra 都柏林・IT 顧問 / 服務 技術顧問職缺。 techmahindra.com/careers →

## 05金融、銀行與保險

- 61 Citibank Europe 都柏林・銀行 / 金融 重要的歐洲樞紐。財資、風險、法遵與技術。 jobs.citi.com →
- 62 JPMorgan Chase 都柏林・銀行 / 金融 技術、風險、法遵與營運。 jpmorgan.com/careers →
- 63 Goldman Sachs 都柏林・銀行 / 金融 技術、營運與財務職能。 goldmansachs.com/careers →
- 64 Bank of Ireland 都柏林・銀行 / 金融 愛爾蘭最大的銀行之一。技術、風險、法遵與資料。 bankofireland.com/careers →
- 65 AIB (Allied Irish Banks) 都柏林・銀行 / 金融 技術、資料與風險專才。 aib.ie/careers →
- 66 Bank of America Europe 都柏林・銀行 / 金融 風險、法遵、技術與營運。 bankofamerica.com/careers →
- 67 BNY Mellon Fund Services 都柏林・資產管理 / 金融 基金行政、技術與財務職缺。 bnymellon.com/careers →
- 68 State Street Technology Ireland 都柏林 / Kilkenny・資產管理 / 金融 量化、法遵、風險與技術職缺。 statestreet.com/careers →
- 69 Northern Trust Limerick / 都柏林・資產管理 / 金融 財務、法遵與技術職缺。Limerick 生活成本低很多。 northerntrust.com/careers →
- 70 Fidelity Investments 都柏林 / Galway・資產管理 / 金融 技術與金融服務職缺。 jobs.fidelity.com →
- 71 Optum Services Ireland 都柏林・健康保險 / 科技 最讓人意外的高量辦簽者之一。健康科技與營運職缺。 optum.com/careers →
- 72 Chase Paymentech Europe 都柏林・金融科技 / 支付 支付技術與營運，隸屬 JPMorgan。 jpmorgan.com/careers →
- 73 Citco Fund Services Ireland 都柏林・基金行政 / 金融 基金行政、技術與財務職缺。 citco.com/careers →
- 74 AerCap 冷門推薦 都柏林・航空 / 飛機租賃 全球最大的飛機租賃公司，總部就在都柏林。財務、法務、工程與商務。航空圈以外幾乎沒人知道，但辦簽紀錄很穩。 aercap.com/careers →
- 75 Flutter Entertainment 都柏林・博弈 / 科技 Paddy Power、Betfair 與 FanDuel 的母公司。技術、產品、資料與營運。 flutter.com/careers →
- 76 Aviva Group Services Ireland 都柏林・保險 / 金融 保險與金融服務職缺。 aviva.ie/careers →
- 77 Canada Life Group Services 都柏林・保險 / 金融 保險與金融服務職缺。 canadalife.ie/careers →

## 06製藥、醫材與生技

如果你念的是化學、生物、生醫、化工、材料，這一段就是你的主戰場。愛爾蘭是全球製藥製造的核心基地之一，而且大部分職缺不在都柏林，在 Cork、Galway、Sligo。

- 78 Pfizer Ireland Pharmaceuticals 都柏林 / Cork / Ringaskiddy・製藥 愛爾蘭最大雇主之一。工程、科學、營運、品保與法規。 pfizer.com/careers →
- 79 Eli Lilly Cork / Kinsale・製藥 多個愛爾蘭實體，全國製藥辦簽量最高的公司之一。Cork 的製造基地是重鎮。 lilly.com/careers →
- 80 AstraZeneca 都柏林・製藥 重要的製造與研發營運。穩定辦簽。 astrazeneca.com/careers →
- 81 Johnson & Johnson Cork / 都柏林・製藥 / 醫材 製藥生產與醫療器材。工程、品保、供應鏈與研發。 jobs.jnj.com →
- 82 AbbVie 都柏林 / Sligo・生物製藥 製造與商業營運。科學、工程、財務與 IT。 careers.abbvie.com →
- 83 MSD (Merck) 都柏林 / Carlow / Tipperary・製藥 愛爾蘭有數個生產基地。科學、工程、IT 與營運。 msd.com/careers →
- 84 Abbott Ireland Clonmel / Longford / 都柏林・醫材 / 診斷 多個生產基地。工程、科學、品保與營運。 abbott.com/careers →
- 85 Boston Scientific Galway / Cork・醫材 Galway 是主要據點，全國最活躍的醫材辦簽者之一。 bostonscientific.com/careers →
- 86 Medtronic 都柏林 / Galway・醫材 財務、業務、醫學事務、工程與研發。 medtronic.com/careers →
- 87 WuXi Biologics Ireland 冷門推薦 都柏林・生技 / 委託製造 知名度不高，但是規模可觀的雇主和活躍的辦簽者。 wuxibiologics.com/careers →
- 88 ICON Clinical Research 都柏林・臨床研究 / CRO 總部設在都柏林的全球臨床研究組織。臨床營運、資料管理、法規事務與專案管理。 iconplc.com/careers →
- 89 SK Biotek Ireland 都柏林・生技 / CDMO 有生技製造經驗的話值得鎖定。 skpharmteco.com/careers →
- 90 Chanelle Pharmaceuticals 冷門推薦 Galway・動物用 / 人用製藥 愛爾蘭本土製藥廠。活躍且穩定的辦簽者。名氣遠不如跨國公司，但機會是真的。 chanelle.com/careers →
- 91 Schivo Medical 愛爾蘭・醫材 / 醫療器械 愛爾蘭精密醫療器材製造商。活躍辦簽者。 schivo.ie/careers →
- 92 Allergan Pharmaceuticals Ireland 都柏林・製藥 / 醫材 隸屬 AbbVie。製造與商業營運。 careers.abbvie.com →
- 93 Kerry Group Tralee / 都柏林・食品科學 / 原料 總部在愛爾蘭的全球食品與飲料原料公司。食品科學、工程、研發與供應鏈。食品科學系學生的隱藏路線。 kerrygroup.com/careers →

## 07工程與工業

- 94 Intel Ireland Leixlip / 都柏林・半導體 / 製造 數十年來愛爾蘭最重要的雇主之一。Kildare 郡 Leixlip 的大型晶圓廠。 intel.com/jobs →
- 95 Eaton Corporation 冷門推薦 都柏林・電力管理 / 工程 全球總部就設在都柏林。工程、技術、財務與供應鏈。多數人不知道這是一家「總部在愛爾蘭」的公司。 eaton.com/careers →
- 96 Trane Technologies 冷門推薦 都柏林・空調 / 製造 / 工程 全球總部在愛爾蘭。工程、製造、財務與供應鏈。最被低估的愛爾蘭總部型跨國公司之一。 tranetechnologies.com/careers →
- 97 Johnson Controls Cork / 都柏林・建築科技 / 工程 工程、技術與營運。 johnsoncontrols.com/careers →
- 98 Kingspan Group Cavan / 都柏林・建材 / 隔熱 總部在愛爾蘭的全球建材公司。工程、製造與商務。 kingspan.com/careers →
- 99 Emerson Automation Solutions Ireland 都柏林・工業自動化 工業自動化與工程職缺。幾乎不會出現在一般求職清單上的活躍辦簽者。 emerson.com/careers →
- 100 FieldCore Service Solutions 都柏林・工業服務 / GE 隸屬 GE Vernova。高量辦簽者。工業工程與現場服務職缺。 fieldcore.com/careers →
- 101 PM Group 都柏林 / Cork・工程 / 製藥廠建設 工程師、專案經理與估算師的穩定辦簽者。是愛爾蘭的重要雇主，但大部分人完全沒聽過。 pmgroup-global.com/careers →
- 102 Jacobs Engineering Ireland 都柏林・工程 / 基礎建設 在基礎建設、製藥與科技專案上都有實力。 jacobs.com/careers →
- 103 Turner & Townsend 都柏林・專案管理 營建與基礎建設領域的專案管理、成本管理與顧問。 turnerandtownsend.com/careers →
- 104 Dornan Engineering Cork・機電工程 愛爾蘭工程承包商。活躍辦簽者，製藥廠專案經驗豐富。 dornan.com/careers →
- 105 Kirby Group Engineering Limerick・工程 / 營建 愛爾蘭工程承包商。製藥、資料中心與基礎建設專案的活躍辦簽者。 kirbygroup.com/careers →

## 08醫療照護：最少人講、最大的缺口

這一段是整份清單裡最重要、也最多人跳過的部分。

醫療照護不是愛爾蘭的其中一個產業，它是全國國際招聘的最大類別。有三家醫院常年排在全國辦簽量的前段班，還有幾十家安養與照護機構每個月都在辦簽。

如果你念的是護理、醫學、醫檢、放射、職能治療、物理治療、社工，你手上的東西比你以為的值錢很多。愛爾蘭現在是全世界最積極對外招募這些人的市場之一。

- 106 Health Service Executive (HSE) 全國・公立醫療 愛爾蘭的公醫體系，常年排在全國辦簽量前列。醫師、護理師、放射師與各類醫事人員。有專門給非歐盟人選的國際招募管道。 hse.ie/eng/staff/jobs →
- 107 Cork University Hospital Cork・公立醫療 全國單一機構辦簽量最高的其中一家。醫療與護理職缺的積極國際招募者。 cuh.hse.ie →
- 108 University Limerick Hospitals Group Limerick・公立醫療 醫療、護理與醫事人員。穩定的高量辦簽者。 hse.ie/jobs →
- 109 Our Lady of Lourdes Hospital Drogheda Drogheda・公立醫療 全國辦簽量前列。醫療與護理職缺。 hse.ie/jobs →
- 110 University Hospital Kerry Kerry・公立醫療 穩定辦簽。醫療與護理職缺。 hse.ie/jobs →
- 111 Galway University Hospital Galway・公立醫療 大型教學醫院。醫療、護理與專科職缺。 saolta.ie →
- 112 Letterkenny University Hospital Donegal・公立醫療 醫療、護理與醫事人員的穩定辦簽者。 hse.ie/jobs →
- 113 Children's Health Ireland 都柏林・兒童醫療 愛爾蘭的國家兒童醫院。醫療、護理與專科職缺，積極對外招募。 childrenshealthireland.ie/careers →
- 114 Bon Secours Health System 都柏林 / Cork / Galway / Limerick・私立醫療 愛爾蘭最大的私立醫院集團。多院區同時辦簽。 bonsecours.ie/careers →
- 115 Alliance Medical Diagnostic Imaging 全國・放射 / 影像診斷 放射師、放射科醫師與影像診斷專業人員的高量辦簽者。 alliancemedical.ie/careers →
- 116 St. Vincent's Healthcare Group 都柏林・公立 / 私立醫療 都柏林重要的醫院集團。醫療、護理與專科職缺。 stvincents.ie →
- 117 TUSLA (Child and Family Agency) 全國・社會工作 愛爾蘭的兒童與家庭署。社工與家庭支持專業人員的活躍辦簽者。 tusla.ie/careers →

本文的許可門檻、處理時間與統計數字，來源為愛爾蘭 DETE 公開資料。移民規則會變動，實際申請前請以 enterprise.gov.ie 與 irishimmigration.ie 的官方公告為準。學生身分的實習、畢業後留任等規定另有專章，投遞前務必自行核對你目前的簽證類別。

## 清單到這裡結束

117 家公司、地點、產業、職缺頁，還有政府的查證入口，全部在上面了。

我在都柏林工作、看著身邊的人來來去去這幾年，最常聽到的一句話是「我以為愛爾蘭只有 Google 跟 Meta」。很多人不是不夠格，只是在看一份太短的名單。

現在這份名單在你手上了。機會的部分，已經被解決了。

但接下來會發生什麼，我也想先跟你說清楚。

最後說一句真心話。

我在都柏林工作，每天在辦公室裡看到的同事來自二十幾個國家。他們不是特別天才，也不是特別幸運。他們只是知道有這些公司、知道怎麼投、然後真的投了。

機會是真的。公司是查得到的。路徑是清楚的。

今天先挑 10 家，把清單建起來。加油！

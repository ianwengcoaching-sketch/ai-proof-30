# 十家 Sequoia 投資的公司正在歐洲招人：在你投履歷之前，先學會讀這份清單
網址：https://www.careergoglobal.com/guide/SNFEFo24wZwCeLxxN

Sequoia 這兩年在歐美投了一批 AI 與軟體公司，其中不少現在正在快速擴編。以下十家，各自在做什麼、募了多少、目前在哪些城市開缺。

01

Edra

把企業既有的營運資料變成 AI agent 可執行的知識庫，用來自動化企業流程。創辦團隊出自 Palantir，2026 年帶著 Sequoia 領投的一輪出 stealth。

- 約 3,000 萬美元 A 輪 · Sequoia 領投，8VC 與 A* 跟投 · 紐約、倫敦

edra.ai →

02

Magentic

為採購與供應鏈團隊部署 AI agent，在關稅與供應鏈波動的環境裡找出可以省下來的成本。英國公司，Sequoia 投資，屬於 Arc 2024 梯次。

- 約 550 萬美元種子輪 · Sequoia 領投 · 倫敦

magentic.com →

03

Ineffable Intelligence

DeepMind 出身的 David Silver 創辦的 AI 研究實驗室，目標是做出不依賴人類資料、能自我學習的系統。以歐洲史上最大的種子輪之一登場。

- 約 11 億美元種子輪 · 估值約 51 億美元 · Sequoia 與 Lightspeed 共同領投，Nvidia、Google 跟投 · 倫敦

ineffable.ai →

04

Reflection AI

做自主 AI 系統，從程式撰寫 agent 出發，往前沿模型延伸，定位是開放權重的前沿實驗室。Sequoia 於 2024 年投資。

- 舊金山、紐約、倫敦：約 20 億美元 B 輪

reflection.ai/careers →

05

n8n

給技術團隊用的工作流程與 AI 自動化平台，可以串接各種工具與模型，採 fair-code 授權。Sequoia 從 2020 年就投資，是它在德國的第一筆種子投資。

- 累計超過 2.5 億美元 · 2025 年 1.8 億美元 C 輪，估值約 25 億美元 · 柏林，其餘歐洲遠端

n8n.io/careers →

06

ElevenLabs

AI 語音與音訊技術的領先者，以擬真的文字轉語音、語音克隆與配音聞名。Sequoia 自 2023 年起投資。

- 累計約 7 到 8 億美元 · 2026 年初 5 億美元 D 輪，估值 110 億美元 · 倫敦、紐約、華沙

elevenlabs.io/careers →

07

Pennylane

法國的財務管理與會計平台，服務中小企業與他們的會計師事務所。Sequoia 2021 年就開始合作。

- 累計超過 4.5 億美元 · 近期約 2 億美元一輪，估值約 42.5 億美元 · 巴黎

pennylane.com →

08

STARK

開發自主防務系統與軟體，包含 AI 無人機，是歐洲國防科技這一波快速成長的代表之一。

- 累計約 6 億美元 · 2026 年由 Sequoia 與 Founders Fund 領投，估值約 32 億歐元 · 柏林總部，另有慕尼黑、斯德哥爾摩、英國

stark-defence.com →

09

Tacto

為中型製造業做採購與供應鏈的 AI 技術，協助工業公司管理供應商、應變中斷與合規。Sequoia 與 Index Ventures 早期投資。

- 累計約 1 億歐元：慕尼黑

tacto.ai/en/career →

10

Pydantic

Python 與 AI agent 的開發者基礎建設，建立在極受歡迎的開源資料驗證套件之上，現在透過 Logfire 等雲端服務商業化。Sequoia 2023 年投資。

- 累計約 1,700 萬美元 · 種子輪加 A 輪 · 英國

pydantic.dev →

※ 本文整理之公司資訊、募資金額與辦公城市僅供職涯參考，不構成任何投資建議。各公司營運狀況與招募需求可能隨時變動，投遞前請自行到官方職缺頁確認。

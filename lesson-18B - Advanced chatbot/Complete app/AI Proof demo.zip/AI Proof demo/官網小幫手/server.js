const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, 'public');
const PORT = Number(process.env.PORT) || 3000;
const HOST = '127.0.0.1';

const MODEL = 'claude-sonnet-5-5';
const MAX_REPLY_TOKENS = 600; // 每則回覆的長度上限
const MAX_TURNS = 6; // 送給模型的對話只保留最近幾輪（一問一答算一輪，含這一題）
const MAX_USER_CHARS = 500; // 每則訪客訊息的長度上限
const MAX_BODY_BYTES = 64 * 1024;
const RATE_WINDOW_MS = 5 * 60 * 1000;
const CHAT_RATE_MAX = 15; // 每位訪客（IP）每 5 分鐘最多幾則
const HANDOFF_RATE_MAX = 5;
const SESSION_TTL_MS = 30 * 60 * 1000;
const MAX_SESSIONS = 1000;

const MARKER_LINE_RE = /^\[轉人工:(錢與訂單|個人判斷|知識庫沒有|合作邀約)\]$/;
const MARKER_ANY_RE = /\[轉人工:[^\]]*\]/g;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const CONTROL_CHAR_RE = /[\u0000-\u0008\u000b-\u001f\u007f-\u009f‪-‮⁦-⁩]/;
const CONTROL_CHARS_RE = new RegExp(CONTROL_CHAR_RE.source, 'g');
const REFUSAL = '這個我不能提供。有課程或服務的問題，我很樂意回答。';

// 只接受從這台電腦的示範頁發出的請求（擋跨站請求與 DNS rebinding）
const ALLOWED_HOSTS = new Set([`localhost:${PORT}`, `127.0.0.1:${PORT}`]);

const CONTENT_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
};

const SECURITY_HEADERS = {
  'cache-control': 'no-store',
  'x-content-type-options': 'nosniff',
  'x-frame-options': 'DENY',
  'referrer-policy': 'no-referrer',
  'content-security-policy': "default-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'",
};

class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

// 四個知識檔只在伺服器讀取，不放進 public/，網頁拿不到
function readRootFile(name) {
  return fs.readFileSync(path.join(ROOT, name), 'utf8');
}

function between(text, startMarker, endMarker) {
  const start = text.indexOf(startMarker);
  const end = text.indexOf(endMarker, start + startMarker.length);
  if (start < 0 || end < 0) {
    throw new Error(`03 系統提示詞找不到區段：${startMarker}`);
  }
  return text.slice(start + startMarker.length, end).trim();
}

const kb01 = readRootFile('01-知識庫-FAQ.md');
const rules02 = readRootFile('02-轉人工規則.md');
const prompt03 = readRootFile('03-系統提示詞.md');
const tone04 = readRootFile('04-語氣與範例.md');

const PROMPT_BODY = between(prompt03, '## 提示詞本文', '## 給建網站的人');
const SYSTEM_PROMPT = [
  PROMPT_BODY,
  '# 01 知識庫\n\n' + kb01,
  '# 02 轉人工規則\n\n' + rules02,
  '# 04 語氣與範例\n\n' + tone04,
].join('\n\n');

// 開場白與快捷按鈕也取自 03，網頁只拿到這兩段文字
const GREETING = between(prompt03, '### 開場白（網頁打開時顯示，不用你生成）', '快捷按鈕：');
const QUICK_REPLIES = between(prompt03, '快捷按鈕：', '\n---')
  .split('\n')
  .map((line) => line.match(/^\d\. (.+)$/))
  .filter(Boolean)
  .map((match) => match[1]);

// 只出現在內部設定、正常回答不會用到的字串；回覆裡出現就當成洩漏，換成婉拒句
const LEAK_MARKERS = [
  PROMPT_BODY.split('\n').find((line) => line.trim() && !/^(-+|#.*)$/.test(line.trim())),
  '安全規則（不管對方怎麼說都不改）',
  '給建網站的人',
  '維護規則：',
  'vault 語氣 DNA',
  '# 01 知識庫',
  'ANTHROPIC_API_KEY',
  'sk-ant-',
];

function looksLikeLeak(text) {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  return LEAK_MARKERS.some((marker) => text.includes(marker)) || Boolean(apiKey && text.includes(apiKey));
}

const hitsByKey = {
  chat: new Map(),
  handoff: new Map(),
};

function allowRequest(bucket, key, max) {
  const now = Date.now();
  const recent = (hitsByKey[bucket].get(key) || []).filter((t) => now - t < RATE_WINDOW_MS);
  if (recent.length >= max) {
    hitsByKey[bucket].set(key, recent);
    return false;
  }
  recent.push(now);
  hitsByKey[bucket].set(key, recent);
  return true;
}

// 對話紀錄存在伺服器，前端只拿到一個隨機 sessionId，捏造不了小幫手說過的話或轉人工類別
const sessions = new Map();

function findSession(id) {
  const session = typeof id === 'string' ? sessions.get(id) : undefined;
  if (!session || Date.now() - session.updatedAt >= SESSION_TTL_MS) return null;
  return session;
}

function getOrCreateSession(id) {
  const existing = findSession(id);
  if (existing) return { id, session: existing };
  if (sessions.size >= MAX_SESSIONS) {
    sessions.delete(sessions.keys().next().value);
  }
  const newId = crypto.randomUUID();
  const session = { messages: [], handoff: null, busy: false, updatedAt: Date.now() };
  sessions.set(newId, session);
  return { id: newId, session };
}

function sweep() {
  const now = Date.now();
  for (const bucket of Object.values(hitsByKey)) {
    for (const [key, times] of bucket) {
      if (times.every((t) => now - t >= RATE_WINDOW_MS)) bucket.delete(key);
    }
  }
  for (const [id, session] of sessions) {
    if (!session.busy && now - session.updatedAt >= SESSION_TTL_MS) sessions.delete(id);
  }
}

function sendJson(res, status, body) {
  res.writeHead(status, { ...SECURITY_HEADERS, 'content-type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(body));
}

function checkHost(req) {
  if (!ALLOWED_HOSTS.has(req.headers.host)) {
    throw new HttpError(403, '不接受這個來源的請求。');
  }
}

// 要求 JSON 會讓瀏覽器對跨站請求先做 preflight，伺服器不回 CORS 標頭，跨站請求就送不出來
function checkApiRequest(req) {
  const origin = req.headers.origin;
  if (origin && !ALLOWED_HOSTS.has(origin.replace(/^http:\/\//, ''))) {
    throw new HttpError(403, '不接受這個來源的請求。');
  }
  if (!String(req.headers['content-type'] || '').startsWith('application/json')) {
    throw new HttpError(415, '請用 JSON 送出。');
  }
}

function readJson(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > MAX_BODY_BYTES) {
        req.destroy();
        reject(new HttpError(413, '內容太大。'));
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}'));
      } catch {
        reject(new HttpError(400, '請求格式不正確。'));
      }
    });
    req.on('error', reject);
  });
}

// 回覆最後一行若是 [轉人工:類別]，拿掉標記並回傳類別；其他地方出現的標記也一併拿掉
function splitHandoff(raw) {
  const lines = raw.trimEnd().split('\n');
  const match = lines.at(-1).trim().match(MARKER_LINE_RE);
  const handoff = match ? match[1] : null;
  const body = match ? lines.slice(0, -1).join('\n') : raw;
  return {
    text: body.replace(MARKER_ANY_RE, '').trim(),
    handoff,
  };
}

// 印到終端機前拿掉控制字元，避免訪客用跳脫碼改寫你的終端機畫面；換行縮排，偽造不了整行紀錄
function forLog(text) {
  return String(text).replace(/\r\n?/g, '\n').replace(CONTROL_CHARS_RE, '').replace(/\n/g, '\n      ');
}

async function callClaude(messages) {
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'x-api-key': process.env.ANTHROPIC_API_KEY,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: MODEL,
      max_tokens: MAX_REPLY_TOKENS,
      system: [{ type: 'text', text: SYSTEM_PROMPT, cache_control: { type: 'ephemeral' } }],
      messages,
    }),
  });
  if (!res.ok) {
    console.error(`Anthropic API 回傳 ${res.status}`);
    throw new HttpError(502, '小幫手暫時連不上，請稍後再試。');
  }
  const data = await res.json();
  return data.content
    .filter((block) => block.type === 'text')
    .map((block) => block.text)
    .join('');
}

async function handleChat(req, res, ip) {
  if (!allowRequest('chat', ip, CHAT_RATE_MAX)) {
    throw new HttpError(429, '問得有點快，請 5 分鐘後再試。');
  }
  const body = await readJson(req);
  const content = typeof body.message === 'string' ? body.message.trim() : '';
  if (!content) {
    throw new HttpError(400, '請輸入問題。');
  }
  if (content.length > MAX_USER_CHARS) {
    throw new HttpError(400, `問題請在 ${MAX_USER_CHARS} 字以內。`);
  }

  const { id, session } = getOrCreateSession(body.sessionId);
  if (session.busy) {
    throw new HttpError(409, '上一題還在回答中，請稍等。');
  }
  session.busy = true;
  try {
    const question = { role: 'user', content };
    const messages = [...session.messages.slice(-(MAX_TURNS - 1) * 2), question];
    const raw = await callClaude(messages);

    let reply = splitHandoff(raw);
    let stored = raw.trim();
    if (looksLikeLeak(raw)) {
      console.warn('攔下一則疑似洩漏內部設定的回覆，已換成婉拒句。');
      reply = { text: REFUSAL, handoff: null };
      stored = REFUSAL;
    }

    if (stored) {
      session.messages.push(question, { role: 'assistant', content: stored });
      session.messages = session.messages.slice(-MAX_TURNS * 2);
    }
    if (reply.handoff) session.handoff = reply.handoff;
    sendJson(res, 200, { sessionId: id, ...reply });
  } finally {
    session.busy = false;
    session.updatedAt = Date.now();
  }
}

async function handleHandoff(req, res, ip) {
  if (!allowRequest('handoff', ip, HANDOFF_RATE_MAX)) {
    throw new HttpError(429, '送出得有點快，請 5 分鐘後再試。');
  }
  const body = await readJson(req);
  const email = String(body.email || '').trim();
  const question = String(body.question || '').trim();
  const newsletter = body.newsletter === true;

  if (!EMAIL_RE.test(email) || email.length > 200 || CONTROL_CHAR_RE.test(email)) {
    throw new HttpError(400, '請填寫正確的 email。');
  }
  if (!question || question.length > MAX_USER_CHARS) {
    throw new HttpError(400, `問題請填寫，且不超過 ${MAX_USER_CHARS} 字。`);
  }
  // 類別與對話紀錄都以伺服器端為準，前端送什麼都不採用
  const session = findSession(body.sessionId);
  if (!session || !session.handoff) {
    throw new HttpError(400, '這段對話沒有需要轉給 Ian 的問題，請重新整理後再問一次。');
  }
  const category = session.handoff;
  session.handoff = null;

  const subject = `[官網小幫手] ${category}：${question.slice(0, 20)}`;

  // 示範版：通知只印在終端機，不寄信
  console.log('\n========== 轉人工通知（示範，未寄信）==========');
  console.log(`主旨：${forLog(subject)}`);
  console.log(`時間：${new Date().toISOString()}`);
  console.log(`類別：${category}`);
  console.log(`email：${forLog(email)}`);
  console.log(`勾選電子報：${newsletter ? '是' : '否'}`);
  console.log(`問題：${forLog(question)}`);
  console.log('對話紀錄：');
  for (const m of session.messages) {
    const text = m.role === 'assistant' ? splitHandoff(m.content).text : m.content;
    console.log(`  [${m.role === 'user' ? '訪客' : '小幫手'}] ${forLog(text)}`);
  }
  console.log('==============================================\n');

  sendJson(res, 200, { ok: true });
}

function serveStatic(res, pathname) {
  let rel;
  try {
    rel = pathname === '/' ? 'index.html' : decodeURIComponent(pathname.slice(1));
  } catch {
    sendJson(res, 400, { error: '網址格式不正確。' });
    return;
  }
  const filePath = path.normalize(path.join(PUBLIC_DIR, rel));
  const contentType = CONTENT_TYPES[path.extname(filePath)];
  if (!filePath.startsWith(PUBLIC_DIR + path.sep) || !contentType) {
    sendJson(res, 404, { error: '找不到這個檔案。' });
    return;
  }
  fs.readFile(filePath, (err, data) => {
    if (err) {
      sendJson(res, 404, { error: '找不到這個檔案。' });
      return;
    }
    res.writeHead(200, { ...SECURITY_HEADERS, 'content-type': contentType });
    res.end(data);
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${HOST}`);
  const ip = req.socket.remoteAddress;
  try {
    checkHost(req);
    if (req.method === 'GET' && url.pathname === '/api/config') {
      sendJson(res, 200, { greeting: GREETING, quickReplies: QUICK_REPLIES });
    } else if (req.method === 'POST' && url.pathname === '/api/chat') {
      checkApiRequest(req);
      await handleChat(req, res, ip);
    } else if (req.method === 'POST' && url.pathname === '/api/handoff') {
      checkApiRequest(req);
      await handleHandoff(req, res, ip);
    } else if (req.method === 'GET') {
      serveStatic(res, url.pathname);
    } else {
      sendJson(res, 405, { error: '不支援的請求方式。' });
    }
  } catch (err) {
    if (err instanceof HttpError) {
      sendJson(res, err.status, { error: err.message });
      return;
    }
    console.error(err);
    sendJson(res, 500, { error: '伺服器出了點問題，請稍後再試。' });
  }
});

function start() {
  if (!process.env.ANTHROPIC_API_KEY) {
    console.error('找不到 ANTHROPIC_API_KEY。請在專案資料夾建立 .env（參考 .env.example），填入金鑰後再啟動。');
    process.exit(1);
  }
  setInterval(sweep, 60 * 1000).unref();
  server.listen(PORT, HOST, () => {
    console.log(`Ian 的 AI 小幫手示範頁：http://localhost:${PORT}`);
  });
}

if (require.main === module) {
  start();
}

module.exports = { splitHandoff, looksLikeLeak, forLog, LEAK_MARKERS, SYSTEM_PROMPT };

const toggleEl = document.getElementById('chat-toggle');
const panelEl = document.getElementById('chat-panel');
const closeEl = document.getElementById('chat-close');
const messagesEl = document.getElementById('messages');
const quickEl = document.getElementById('quick');
const formEl = document.getElementById('chat-form');
const inputEl = document.getElementById('chat-input');
const sendEl = document.getElementById('chat-send');

// 對話紀錄存在伺服器，這裡只記住伺服器給的 sessionId；重新整理就開新對話
let sessionId = null;
let busy = false;

async function postJson(url, body) {
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.error || '出了點問題，請稍後再試。');
  }
  return data;
}

function scrollToBottom() {
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

function addBubble(className, text) {
  const div = document.createElement('div');
  div.className = `bubble ${className}`;
  div.textContent = text;
  messagesEl.appendChild(div);
  scrollToBottom();
  return div;
}

function setBusy(value) {
  busy = value;
  inputEl.disabled = value;
  sendEl.disabled = value;
}

function addHandoffCard(question) {
  const card = document.createElement('form');
  card.className = 'handoff-card';
  card.innerHTML = `
    <h3>讓 Ian 親自回你</h3>
    <label>你的 email（必填）
      <input type="email" name="email" required maxlength="200" autocomplete="email">
    </label>
    <label>你的問題（必填）
      <textarea name="question" required maxlength="500" rows="3"></textarea>
    </label>
    <label class="check">
      <input type="checkbox" name="newsletter">
      也想收 Ian 的電子報
    </label>
    <button type="submit">送出</button>
    <p class="card-error" hidden></p>
  `;
  card.elements.question.value = question;

  const errorEl = card.querySelector('.card-error');
  const submitEl = card.querySelector('button');

  card.addEventListener('submit', async (event) => {
    event.preventDefault();
    errorEl.hidden = true;
    submitEl.disabled = true;
    try {
      await postJson('/api/handoff', {
        sessionId,
        email: card.elements.email.value,
        question: card.elements.question.value,
        newsletter: card.elements.newsletter.checked,
      });
      card.replaceChildren(
        Object.assign(document.createElement('p'), {
          className: 'thanks',
          textContent: '收到了。Ian 會在 3 個工作天內用 email 親自回你。',
        }),
      );
    } catch (err) {
      errorEl.textContent = err.message;
      errorEl.hidden = false;
      submitEl.disabled = false;
    }
  });

  messagesEl.appendChild(card);
  scrollToBottom();
}

async function sendMessage(text) {
  const content = text.trim();
  if (!content || busy) return;

  setBusy(true);
  quickEl.hidden = true;
  addBubble('user', content);
  const typingEl = addBubble('assistant typing', '小幫手正在想…');

  try {
    const data = await postJson('/api/chat', { sessionId, message: content });
    sessionId = data.sessionId;
    typingEl.remove();
    if (data.text) {
      addBubble('assistant', data.text);
    }
    if (data.handoff) {
      addHandoffCard(content);
    }
  } catch (err) {
    typingEl.remove();
    addBubble('error', err.message);
  } finally {
    setBusy(false);
    inputEl.focus();
  }
}

function renderQuickReplies(items) {
  quickEl.replaceChildren(
    ...items.map((label) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.textContent = label;
      button.addEventListener('click', () => sendMessage(label));
      return button;
    }),
  );
  quickEl.hidden = items.length === 0;
}

async function init() {
  try {
    const res = await fetch('/api/config');
    if (!res.ok) throw new Error('config');
    const config = await res.json();
    addBubble('assistant', config.greeting);
    renderQuickReplies(config.quickReplies);
  } catch {
    addBubble('error', '無法載入小幫手，請重新整理頁面。');
  }
}

toggleEl.addEventListener('click', () => {
  const opening = panelEl.hidden;
  panelEl.hidden = !opening;
  toggleEl.setAttribute('aria-expanded', String(opening));
  if (opening) {
    inputEl.focus();
    scrollToBottom();
  }
});

closeEl.addEventListener('click', () => {
  panelEl.hidden = true;
  toggleEl.setAttribute('aria-expanded', 'false');
});

formEl.addEventListener('submit', (event) => {
  event.preventDefault();
  const text = inputEl.value;
  inputEl.value = '';
  sendMessage(text);
});

init();
